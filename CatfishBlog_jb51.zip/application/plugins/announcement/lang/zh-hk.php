<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2016/12/6
 */
return [
    'Announcement' => '公告',
    'The Announcement Plugin displays a bulletin at the top of the Home page' => '公告插件可以在首頁的頂部顯示一條公告',
    'Notice content' => '公告內容',
    'Save' => '保存'
];