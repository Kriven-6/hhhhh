<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'The site needs to take a break!' => 'Сайт нужен перерыв!',
    'In the system maintenance, please come again tomorrow' => 'Техническое обслуживание системы, пожалуйста, приходите завтра',
    'Temporarily closed' => 'Временно закрыт'
];