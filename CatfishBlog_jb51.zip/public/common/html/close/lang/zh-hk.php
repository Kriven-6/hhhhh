<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'The site needs to take a break!' => '網站需要休息一下!',
    'In the system maintenance, please come again tomorrow' => '系統維​​護中，請明天再來',
    'Temporarily closed' => '暫時關閉'
];