<?php
/**
 * Project: Catfish.
 * Author: A.J
 * Date: 2017/7/19
 */
return [
    'You visit the page out to play!' => 'Vous visitez la page est sorti pour jouer!',
    'The page does not exist, please click the link at the bottom of the page to return' => 'Vous visitez la page n\'existe pas, s\'il vous plaît cliquer sur le bas de la page à revenir',
    'Access error' => 'erreur d\'accès',
    'Return to the home page' => 'maison'
];